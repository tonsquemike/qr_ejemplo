/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package qrexample;

import com.google.zxing.BinaryBitmap;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.EnumMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/**
 *
 * @author mike
 */
public class lectura {
    public static void main(String[] args) throws IOException {
        Map<EncodeHintType, Object> hintMap;
        BufferedImage image = ImageIO.read(new File("skewed.png"));
        try{
            hintMap = new EnumMap<EncodeHintType, Object>(EncodeHintType.class);
        
            String s = readQRCode(image, "UTF-8", hintMap);
            System.out.println("sample = "+s);
        }catch(Exception e){e.printStackTrace();}
        
    }
    public static String readQRCode(BufferedImage filePath, String charset, Map hintMap)
   {
        BinaryBitmap binaryBitmap = new BinaryBitmap(new HybridBinarizer(
                new BufferedImageLuminanceSource(
                        ((filePath)))));
        Result qrCodeResult = null;
        try {
            qrCodeResult = new MultiFormatReader().decode(binaryBitmap);
        } catch (NotFoundException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
        return qrCodeResult.getText();
    }
}
