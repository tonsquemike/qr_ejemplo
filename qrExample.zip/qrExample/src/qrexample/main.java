package qrexample;

import Principal.Rotar;
import Principal.SpecificRotate;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.EnumMap;
import java.util.Map;

import javax.imageio.ImageIO;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.EncodeHintType;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.NotFoundException;
import com.google.zxing.Reader;
import com.google.zxing.ReaderException;
import com.google.zxing.Result;
import com.google.zxing.ResultPoint;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.QRCodeReader;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.google.zxing.qrcode.detector.Detector;
import com.google.zxing.qrcode.detector.FinderPattern;
import java.awt.AlphaComposite;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Crunchify.com Updated: 03/20/2016 - added code to narrow border size
 */
public class main {
    static boolean transparency = true;
    static String interpolation = "bicubic";
    static String    foreground = "white";
    // Tutorial: http://zxing.github.io/zxing/apidocs/index.html
    public static void main(String[] args) {
        Map<EncodeHintType, Object> hintMap;
        BufferedImage image = null;
        String myCodeText = "Cuenta=0715417&"
                + "IDA_TAREA = 340";
        String filePath = "CrunchifyQR.png";
        int size = 500;
        String fileType = "png";
        File myFile = new File(filePath);
        try {

            hintMap = new EnumMap<EncodeHintType, Object>(EncodeHintType.class);
            hintMap.put(EncodeHintType.CHARACTER_SET, "UTF-8");

            // Now with zxing version 3.2.1 you could change border size (white border size to just 1)
            hintMap.put(EncodeHintType.MARGIN, 1);
            /* default = 4 */
            hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
            
            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            BitMatrix byteMatrix = qrCodeWriter.encode(myCodeText, BarcodeFormat.QR_CODE, size,
                    size, hintMap);
            int CrunchifyWidth = byteMatrix.getWidth();
            image = new BufferedImage(CrunchifyWidth, CrunchifyWidth,
                    BufferedImage.TYPE_INT_RGB);
            image.createGraphics();

            Graphics2D graphics = (Graphics2D) image.getGraphics();
            //graphics.setColor(new Color(0, 88, 191));
            graphics.setColor(Color.WHITE);
            graphics.fillRect(0, 0, CrunchifyWidth, CrunchifyWidth);
            graphics.setColor(Color.BLACK);

            for (int i = 0; i < CrunchifyWidth; i++) {
                for (int j = 0; j < CrunchifyWidth; j++) {
                    if (byteMatrix.get(i, j)) {
                        graphics.fillRect(i, j, 1, 1);
                    }
                }
            }
            ImageIO.write(image, fileType, myFile);
        } catch (WriterException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try{
            image = ImageIO.read(new File("entrada.png"));
        }catch(Exception e){}
        
        Map<DecodeHintType,Object> tmpHintsMap = new EnumMap<DecodeHintType, Object>(DecodeHintType.class);
            tmpHintsMap.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
            tmpHintsMap.put(DecodeHintType.PURE_BARCODE, true);


        //hintMap = new EnumMap<EncodeHintType, Object>(EncodeHintType.class);
        try{
            String s = readQRCode(image, "UTF-8", tmpHintsMap);
            System.out.println("texto en QR = "+s);
        }catch(Exception e){e.printStackTrace();}
        
        BufferedImageLuminanceSource b = new BufferedImageLuminanceSource(image);
        HybridBinarizer h = new HybridBinarizer(b);
        BitMatrix bm = null;
        Detector d;
        ResultPoint []p = null;
        try{
            bm = h.getBlackMatrix();
        }catch(Exception e){}
            d  = new Detector(bm);
            
        try{
            p = d.detect().getPoints();
        }catch(Exception e){e.printStackTrace();}
        size = 0;
        System.out.println("-------------");
        
        /*LuminanceSource source = new BufferedImageLuminanceSource(image);
            BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
            
            Result result = null;
            try {
                result = new MultiFormatReader().decode(bitmap);
            }catch(Exception e){}
                ResultPoint[] p1 = result.getResultPoints();
                for (int i = 0; i < p1.length; i++) {
                    System.out.println(p1[i]);
                }
  
        */
        
        for (int i = 0; i < p.length; i++) {
            ResultPoint r = p[i];
            System.out.println(p[i].getX()+","+p[i].getY());
            
            if(r instanceof FinderPattern){
                System.out.println(((FinderPattern) r).getEstimatedModuleSize());          
                size+=((FinderPattern) r).getEstimatedModuleSize();
            }
        }
        
        System.out.println("----------------- size = "+size);
//        Rectangle qrR = new Rectangle((int)p[0].getX(),(int)p[0].getY(), (p[2].getX()-p[1].getX()), (p[1].getY()-p[0].getY()));
        Graphics g = image.getGraphics();
        size = 0;
        g.setColor(Color.red);
        try{g.drawLine((int)p[0].getX()-size, (int)p[0].getY()-size, (int)p[1].getX()-size, (int)p[1].getY()-size);}catch(Exception e){}
        try{g.drawLine((int)p[1].getX()-size, (int)p[1].getY()-size, (int)p[2].getX()-size, (int)p[2].getY()-size);}catch(Exception e){}
        try{g.drawLine((int)p[2].getX()-size, (int)p[2].getY()-size, (int)p[3].getX()-size, (int)p[3].getY()-size);}catch(Exception e){}
        try{g.drawLine((int)p[0].getX()-size, (int)p[0].getY()-size, (int)p[3].getX()-size, (int)p[3].getY()-size);}catch(Exception e){}
        
        try{
            ImageIO.write(image, "png", new File("out.png"));
        }catch(Exception e){}
        Result qrCodeResult = null;
        
        //System.out.println(".----"+qrCodeResult.getText());
        double angle = 
//        Functions_Points.rotatePoint(angle, p[1], points);
        try{
            ImageIO.write(image, "png", new File("out.png"));
        }catch(Exception e){}
        //qrCodeResult = new MultiFormatReader().decode(bm);
        //System.out.println(".----"+qrCodeResult.getText());
        BufferedImage skewed = rotateQR(image, (float)angle);
        try{
            ImageIO.write(skewed, "png", new File("skewed.png"));
        }catch(Exception e){}
    }

    /**
     *
     * @param filePath
     * @param charset
     * @param hintMap
     *
     * @return Qr Code value
     *
     * @throws FileNotFoundException
     * @throws IOException
     * @throws NotFoundException
     */
    public static String readQRCode(BufferedImage filePath, String charset, Map hintMap)
   {
        BinaryBitmap binaryBitmap = new BinaryBitmap(new HybridBinarizer(
                new BufferedImageLuminanceSource(
                        ((filePath)))));
        Result qrCodeResult = null;
        try {
            qrCodeResult = new MultiFormatReader().decode(binaryBitmap);
        } catch (NotFoundException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
        return qrCodeResult.getText();
    }
/*
    public BufferedImage getQRCodeWithOverlay(BufferedImage qrcode) {
        BufferedImage scaledOverlay = scaleOverlay(qrcode);

        Integer deltaHeight = qrcode.getHeight() - scaledOverlay.getHeight();
        Integer deltaWidth = qrcode.getWidth() - scaledOverlay.getWidth();

        BufferedImage combined = new BufferedImage(qrcode.getWidth(), qrcode.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = (Graphics2D) combined.getGraphics();
        g2.drawImage(qrcode, 0, 0, null);
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, overlayTransparency));
        g2.drawImage(scaledOverlay, Math.round(deltaWidth / 2), Math.round(deltaHeight / 2), null);
        return combined;
    }

    private BufferedImage scaleOverlay(BufferedImage qrcode) {
        Integer scaledWidth = Math.round(qrcode.getWidth() * overlayToQRCodeRatio);
        Integer scaledHeight = Math.round(qrcode.getHeight() * overlayToQRCodeRatio);

        BufferedImage imageBuff = new BufferedImage(scaledWidth, scaledHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics g = imageBuff.createGraphics();
        g.drawImage(overlay.getScaledInstance(scaledWidth, scaledHeight, BufferedImage.SCALE_SMOOTH), 0, 0, new Color(0, 0, 0), null);
        g.dispose();
        return imageBuff;
    }*/
    public static BufferedImage rotateQR(BufferedImage image, float angulo)
    {
        BufferedImage salida;
        Rotar r = new Rotar(image);
        r.Rotar(angulo);
        salida = r.getImage();
        //System.out.println(angulo+",");
        //System.out.println(transparency);
        if(r.getAngle()==0)
            salida = image;
        if(r.getAngle()>0)//en caso de que la rotacion sea diferente de 90,180,270 o 360
        {                  //se aplica rotación despues de calcular el nuevo angulo
            SpecificRotate objRotate = new SpecificRotate(salida);
        
            if(transparency==true) 
            {
                objRotate.apllyRotation(r.getAngle(),interpolation, ""         ,".PNG",true);
            }
            else
            {
                objRotate.apllyRotation(r.getAngle(), interpolation, foreground, ""   ,false);
            }

            salida = objRotate.getRotatedImage();    
        }
        return salida;
    }
}
